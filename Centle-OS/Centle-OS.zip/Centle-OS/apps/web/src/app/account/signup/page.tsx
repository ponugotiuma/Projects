/**
 * ⚠ ANYTHING PLATFORM — DO NOT REWRITE THIS FILE ⚠
 *
 * Shipped v2 auth scaffolding. The <form onSubmit>, e.preventDefault(), and
 * window.location.href redirect are load-bearing for the mobile WebView auth
 * flow (AuthWebView intercepts the navigation to capture the session). A
 * prior AI rewrite replaced <form onSubmit> with <button onClick> and broke
 * signup platform-wide — "credentials cleared" / "button does nothing" for
 * every user until a human reverted it. DO NOT repeat that mistake.
 *
 *   Safe:   restyle, rewrite copy, add form fields (pass `name` explicitly).
 *   Unsafe: replacing <form>, removing preventDefault, bypassing
 *           authClient.signUp.email, changing the callbackUrl redirect.
 */
'use client';

import { useSearchParams } from 'next/navigation';
import { type FormEvent, Suspense, useState } from 'react';
import { authClient } from '@/lib/auth-client';
import { Eye, EyeOff, Layers, CheckCircle2, Users, Shield, Zap } from 'lucide-react';
import Link from 'next/link';

const perks = [
  { icon: Shield, text: 'Enterprise-grade security' },
  { icon: Users, text: 'Multi-venture CRM access' },
  { icon: Zap, text: 'AI-powered lead intelligence' },
];

function SignUpForm() {
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get('callbackUrl') || '/dashboard';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error: signUpError } = await authClient.signUp.email({
      email,
      password,
      name: name || email.split('@')[0],
    });

    if (signUpError) {
      setError(signUpError.message ?? 'Sign up failed');
      setLoading(false);
      return;
    }

    if (typeof window !== 'undefined') {
      window.location.href = callbackUrl;
    } else {
      console.warn('signup: window is undefined; cannot redirect to callbackUrl');
    }
  };

  const passwordStrength = (() => {
    if (!password) return { score: 0, label: '', color: 'transparent' };
    let score = 0;
    if (password.length >= 8) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    const levels = [
      { score: 0, label: '', color: 'transparent' },
      { score: 1, label: 'Weak', color: '#EF4444' },
      { score: 2, label: 'Fair', color: '#F59E0B' },
      { score: 3, label: 'Good', color: '#10B981' },
      { score: 4, label: 'Strong', color: '#D4AF37' },
    ];
    return levels[score] || levels[0];
  })();

  return (
    <main
      className="min-h-screen w-full flex items-center justify-center p-4 relative overflow-hidden"
      style={{ background: '#000000' }}
    >
      {/* Animated background blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute w-[600px] h-[600px] rounded-full"
          style={{
            top: '-15%',
            right: '-10%',
            background: 'radial-gradient(circle, rgba(212,175,55,0.08) 0%, transparent 70%)',
            animation: 'floatBlob1 14s ease-in-out infinite',
          }}
        />
        <div
          className="absolute w-[500px] h-[500px] rounded-full"
          style={{
            bottom: '-10%',
            left: '-5%',
            background: 'radial-gradient(circle, rgba(212,175,55,0.05) 0%, transparent 70%)',
            animation: 'floatBlob2 18s ease-in-out infinite',
          }}
        />
      </div>

      <div className="w-full max-w-[1100px] grid grid-cols-1 lg:grid-cols-2 gap-8 relative z-10">
        {/* Left: Info Panel */}
        <div className="hidden lg:flex flex-col justify-center gap-8">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group w-fit">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #D4AF37, #F3E5AB)',
                boxShadow: '0 0 20px rgba(212,175,55,0.4)',
              }}
            >
              <Layers className="text-black w-5 h-5" />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">
              Centle <span style={{ color: '#D4AF37' }}>OS</span>
            </span>
          </Link>

          <div>
            <div
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold mb-6"
              style={{
                background: 'rgba(212,175,55,0.1)',
                border: '1px solid rgba(212,175,55,0.2)',
                color: '#D4AF37',
              }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full"
                style={{ background: '#D4AF37', animation: 'pulse 2s infinite' }}
              />
              Enterprise Platform
            </div>
            <h2 className="text-4xl font-bold text-white mb-4 leading-tight tracking-tight">
              The Operating System
              <br />
              for the <span style={{ color: '#D4AF37' }}>Centle Group</span>
            </h2>
            <p className="text-white/40 text-base leading-relaxed">
              A unified CRM, ERP, and Referral Management platform connecting 6 high-growth ventures
              with AI-driven intelligence.
            </p>
          </div>

          <div className="flex flex-col gap-4">
            {perks.map((perk) => (
              <div key={perk.text} className="flex items-center gap-4">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: 'rgba(212,175,55,0.08)',
                    border: '1px solid rgba(212,175,55,0.15)',
                  }}
                >
                  <perk.icon className="w-5 h-5" style={{ color: '#D4AF37' }} />
                </div>
                <span className="text-sm text-white/60 font-medium">{perk.text}</span>
              </div>
            ))}
          </div>

          {/* Ventures chips */}
          <div>
            <p className="text-xs font-semibold text-white/20 tracking-widest uppercase mb-3">
              Powering 6 Ventures
            </p>
            <div className="flex flex-wrap gap-2">
              {['Saasum AI', 'Skill Tank', 'Promtal', 'Tobofu', 'Maceco', 'Vriddhi'].map((v) => (
                <span
                  key={v}
                  className="px-3 py-1 rounded-full text-xs font-medium"
                  style={{
                    background: 'rgba(255,255,255,0.04)',
                    border: '1px solid rgba(255,255,255,0.08)',
                    color: 'rgba(255,255,255,0.5)',
                  }}
                >
                  {v}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Signup Form */}
        <div className="flex flex-col justify-center">
          {/* Mobile logo */}
          <Link href="/" className="flex lg:hidden items-center gap-2 mb-10 group w-fit">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #D4AF37, #F3E5AB)',
                boxShadow: '0 0 20px rgba(212,175,55,0.4)',
              }}
            >
              <Layers className="text-black w-5 h-5" />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">
              Centle <span style={{ color: '#D4AF37' }}>OS</span>
            </span>
          </Link>

          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">Create account</h1>
            <p className="text-white/40 text-base">Join the Centle Enterprise ecosystem</p>
          </div>

          <div
            className="rounded-3xl p-8"
            style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.08)',
              backdropFilter: 'blur(24px)',
              boxShadow: '0 32px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.05)',
            }}
          >
            <form
              onSubmit={(e) => {
                void onSubmit(e);
              }}
              className="flex flex-col gap-5"
            >
              {/* Name */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-white/50 tracking-widest uppercase">
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Vamshi Krishna"
                  className="w-full h-12 px-4 rounded-xl text-sm text-white placeholder:text-white/20 outline-none transition-all"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.08)',
                  }}
                  onFocus={(e) => {
                    e.target.style.border = '1px solid rgba(212,175,55,0.5)';
                    e.target.style.boxShadow = '0 0 0 3px rgba(212,175,55,0.08)';
                  }}
                  onBlur={(e) => {
                    e.target.style.border = '1px solid rgba(255,255,255,0.08)';
                    e.target.style.boxShadow = 'none';
                  }}
                />
              </div>

              {/* Email */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-white/50 tracking-widest uppercase">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@centleos.com"
                  className="w-full h-12 px-4 rounded-xl text-sm text-white placeholder:text-white/20 outline-none transition-all"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.08)',
                  }}
                  onFocus={(e) => {
                    e.target.style.border = '1px solid rgba(212,175,55,0.5)';
                    e.target.style.boxShadow = '0 0 0 3px rgba(212,175,55,0.08)';
                  }}
                  onBlur={(e) => {
                    e.target.style.border = '1px solid rgba(255,255,255,0.08)';
                    e.target.style.boxShadow = 'none';
                  }}
                />
              </div>

              {/* Password */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-white/50 tracking-widest uppercase">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min. 8 characters"
                    className="w-full h-12 px-4 pr-12 rounded-xl text-sm text-white placeholder:text-white/20 outline-none transition-all"
                    style={{
                      background: 'rgba(255,255,255,0.05)',
                      border: '1px solid rgba(255,255,255,0.08)',
                    }}
                    onFocus={(e) => {
                      e.target.style.border = '1px solid rgba(212,175,55,0.5)';
                      e.target.style.boxShadow = '0 0 0 3px rgba(212,175,55,0.08)';
                    }}
                    onBlur={(e) => {
                      e.target.style.border = '1px solid rgba(255,255,255,0.08)';
                      e.target.style.boxShadow = 'none';
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {/* Password strength */}
                {password && (
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex gap-1 flex-1">
                      {[1, 2, 3, 4].map((level) => (
                        <div
                          key={level}
                          className="h-1 flex-1 rounded-full transition-all duration-300"
                          style={{
                            background:
                              level <= passwordStrength.score
                                ? passwordStrength.color
                                : 'rgba(255,255,255,0.08)',
                          }}
                        />
                      ))}
                    </div>
                    <span
                      className="text-[10px] font-medium"
                      style={{ color: passwordStrength.color }}
                    >
                      {passwordStrength.label}
                    </span>
                  </div>
                )}
              </div>

              {error && (
                <div
                  className="px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: 'rgba(239,68,68,0.08)',
                    border: '1px solid rgba(239,68,68,0.2)',
                    color: '#FCA5A5',
                  }}
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full h-12 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all"
                style={{
                  background: loading
                    ? 'rgba(212,175,55,0.4)'
                    : 'linear-gradient(135deg, #D4AF37, #C5A028)',
                  color: '#000000',
                  boxShadow: loading ? 'none' : '0 0 30px rgba(212,175,55,0.3)',
                  cursor: loading ? 'not-allowed' : 'pointer',
                }}
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span
                      className="w-4 h-4 rounded-full border-2 border-black/20 border-t-black"
                      style={{ animation: 'spin 0.8s linear infinite' }}
                    />
                    Creating account…
                  </span>
                ) : (
                  <>
                    <CheckCircle2 size={16} />
                    Create Account
                  </>
                )}
              </button>
            </form>

            <div className="flex items-center gap-4 my-6">
              <div className="flex-1 h-[1px]" style={{ background: 'rgba(255,255,255,0.06)' }} />
              <span className="text-xs text-white/20">or</span>
              <div className="flex-1 h-[1px]" style={{ background: 'rgba(255,255,255,0.06)' }} />
            </div>

            <p className="text-center text-sm text-white/30">
              Already have an account?{' '}
              <Link
                href={`/account/signin?callbackUrl=${encodeURIComponent(callbackUrl)}`}
                className="font-semibold transition-colors"
                style={{ color: '#D4AF37' }}
              >
                Sign in
              </Link>
            </p>
          </div>

          <p className="text-center text-xs text-white/20 mt-6">
            © 2026 Centle Group. By creating an account you agree to our Terms of Service.
          </p>
        </div>
      </div>

      <style jsx global>{`
        @keyframes floatBlob1 {
          0%,
          100% {
            transform: translate(0, 0) scale(1);
          }
          50% {
            transform: translate(-30px, 20px) scale(1.05);
          }
        }
        @keyframes floatBlob2 {
          0%,
          100% {
            transform: translate(0, 0) scale(1);
          }
          50% {
            transform: translate(20px, -30px) scale(1.03);
          }
        }
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
        @keyframes pulse {
          0%,
          100% {
            opacity: 1;
          }
          50% {
            opacity: 0.3;
          }
        }
      `}</style>
    </main>
  );
}

export default function SignUpPage() {
  return (
    <Suspense>
      <SignUpForm />
    </Suspense>
  );
}
