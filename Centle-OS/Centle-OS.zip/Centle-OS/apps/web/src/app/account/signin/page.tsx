/**
 * ⚠ ANYTHING PLATFORM — DO NOT REWRITE THIS FILE ⚠
 *
 * Shipped v2 auth scaffolding. Same contract as signup/page.tsx: <form
 * onSubmit>, e.preventDefault(), and window.location.href redirect are all
 * load-bearing for the mobile WebView. DO NOT replace <form onSubmit> with
 * <button onClick> — that broke signin platform-wide in a prior AI rewrite.
 *
 *   Safe:   restyle, rewrite copy, add form fields.
 *   Unsafe: replacing <form>, removing preventDefault, bypassing
 *           authClient.signIn.email, changing the callbackUrl redirect.
 */
'use client';

import { useSearchParams } from 'next/navigation';
import { type FormEvent, Suspense, useState } from 'react';
import { authClient } from '@/lib/auth-client';
import { Eye, EyeOff, Layers, ArrowRight, Copy, Check } from 'lucide-react';
import Link from 'next/link';

const demoUsers = [
  {
    role: 'Admin',
    email: 'vamshi.admin-centleos@gmail.com',
    password: 'Admin@CentleOS',
    badge: 'Global Admin',
    color: '#D4AF37',
  },
  {
    role: 'Manager',
    email: 'saikrishna.manager-centleos@gmail.com',
    password: 'Manager@CentleOS',
    badge: 'Saasum AI + Skill Tank',
    color: '#A8D8A8',
  },
  {
    role: 'Operations',
    email: 'pavani.ops-centleos@gmail.com',
    password: 'Ops@CentleOS',
    badge: 'ERP & Invoicing',
    color: '#87CEEB',
  },
  {
    role: 'Sales Rep',
    email: 'priya.sales-centleos@gmail.com',
    password: 'SalesRep@CentleOS',
    badge: 'Lead Management',
    color: '#DDA0DD',
  },
  {
    role: 'Ambassador',
    email: 'vyshnavi.ambassador-centleos@gmail.com',
    password: 'Ambassador@CentleOS',
    badge: 'Referral Program',
    color: '#F4A460',
  },
];

function SignInForm() {
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get('callbackUrl') || '/dashboard';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);
  const [seeding, setSeeding] = useState(false);
  const [seedDone, setSeedDone] = useState(false);

  const seedDemo = async () => {
    setSeeding(true);
    try {
      const res = await fetch('/api/seed', { method: 'POST' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setSeedDone(true);
    } catch (err) {
      console.error('Seed failed:', err);
    } finally {
      setSeeding(false);
    }
  };

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error: signInError } = await authClient.signIn.email({
      email,
      password,
    });

    if (signInError) {
      setError(signInError.message ?? 'Sign in failed');
      setLoading(false);
      return;
    }

    if (typeof window !== 'undefined') {
      window.location.href = callbackUrl;
    } else {
      console.warn('signin: window is undefined; cannot redirect to callbackUrl');
    }
  };

  const fillCredentials = (user: (typeof demoUsers)[0]) => {
    setEmail(user.email);
    setPassword(user.password);
    setError(null);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedEmail(id);
    setTimeout(() => setCopiedEmail(null), 1500);
  };

  return (
    <main
      className="min-h-screen w-full flex items-center justify-center p-4 relative overflow-hidden"
      style={{ background: '#000000' }}
    >
      {/* Animated background blobs */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute w-[600px] h-[600px] rounded-full"
          style={{
            top: '-15%',
            left: '-10%',
            background: 'radial-gradient(circle, rgba(212,175,55,0.08) 0%, transparent 70%)',
            animation: 'floatBlob1 12s ease-in-out infinite',
          }}
        />
        <div
          className="absolute w-[500px] h-[500px] rounded-full"
          style={{
            bottom: '-10%',
            right: '-5%',
            background: 'radial-gradient(circle, rgba(212,175,55,0.05) 0%, transparent 70%)',
            animation: 'floatBlob2 16s ease-in-out infinite',
          }}
        />
        <div
          className="absolute w-[1px] h-full"
          style={{
            left: '50%',
            background:
              'linear-gradient(to bottom, transparent, rgba(212,175,55,0.05), transparent)',
          }}
        />
      </div>

      <div className="w-full max-w-[1100px] grid grid-cols-1 lg:grid-cols-2 gap-8 relative z-10">
        {/* Left: Login Form */}
        <div className="flex flex-col justify-center">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 mb-10 group w-fit">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #D4AF37, #F3E5AB)',
                boxShadow: '0 0 20px rgba(212,175,55,0.4)',
              }}
            >
              <Layers className="text-black w-5 h-5" />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">
              Centle <span style={{ color: '#D4AF37' }}>OS</span>
            </span>
          </Link>

          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">Welcome back</h1>
            <p className="text-white/40 text-base">Sign in to the Centle Enterprise Portal</p>
          </div>

          {/* Form Card */}
          <div
            className="rounded-3xl p-8"
            style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.08)',
              backdropFilter: 'blur(24px)',
              boxShadow: '0 32px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.05)',
            }}
          >
            <form
              onSubmit={(e) => {
                void onSubmit(e);
              }}
              className="flex flex-col gap-5"
            >
              {/* Email field */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-white/50 tracking-widest uppercase">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@centleos.com"
                  className="w-full h-12 px-4 rounded-xl text-sm text-white placeholder:text-white/20 outline-none transition-all"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.08)',
                  }}
                  onFocus={(e) => {
                    e.target.style.border = '1px solid rgba(212,175,55,0.5)';
                    e.target.style.boxShadow = '0 0 0 3px rgba(212,175,55,0.08)';
                  }}
                  onBlur={(e) => {
                    e.target.style.border = '1px solid rgba(255,255,255,0.08)';
                    e.target.style.boxShadow = 'none';
                  }}
                />
              </div>

              {/* Password field */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-white/50 tracking-widest uppercase">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full h-12 px-4 pr-12 rounded-xl text-sm text-white placeholder:text-white/20 outline-none transition-all"
                    style={{
                      background: 'rgba(255,255,255,0.05)',
                      border: '1px solid rgba(255,255,255,0.08)',
                    }}
                    onFocus={(e) => {
                      e.target.style.border = '1px solid rgba(212,175,55,0.5)';
                      e.target.style.boxShadow = '0 0 0 3px rgba(212,175,55,0.08)';
                    }}
                    onBlur={(e) => {
                      e.target.style.border = '1px solid rgba(255,255,255,0.08)';
                      e.target.style.boxShadow = 'none';
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              {error && (
                <div
                  className="px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: 'rgba(239,68,68,0.08)',
                    border: '1px solid rgba(239,68,68,0.2)',
                    color: '#FCA5A5',
                  }}
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full h-12 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all"
                style={{
                  background: loading
                    ? 'rgba(212,175,55,0.4)'
                    : 'linear-gradient(135deg, #D4AF37, #C5A028)',
                  color: '#000000',
                  boxShadow: loading ? 'none' : '0 0 30px rgba(212,175,55,0.3)',
                  cursor: loading ? 'not-allowed' : 'pointer',
                }}
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span
                      className="w-4 h-4 rounded-full border-2 border-black/20 border-t-black"
                      style={{ animation: 'spin 0.8s linear infinite' }}
                    />
                    Authenticating…
                  </span>
                ) : (
                  <>
                    Sign In to Centle OS <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="flex items-center gap-4 my-6">
              <div className="flex-1 h-[1px]" style={{ background: 'rgba(255,255,255,0.06)' }} />
              <span className="text-xs text-white/20">or</span>
              <div className="flex-1 h-[1px]" style={{ background: 'rgba(255,255,255,0.06)' }} />
            </div>

            <p className="text-center text-sm text-white/30">
              New to Centle OS?{' '}
              <Link
                href={`/account/signup?callbackUrl=${encodeURIComponent(callbackUrl)}`}
                className="font-semibold transition-colors"
                style={{ color: '#D4AF37' }}
              >
                Create account
              </Link>
            </p>
          </div>

          <p className="text-center text-xs text-white/20 mt-6">
            © 2026 Centle Group. Enterprise SaaS Platform.
          </p>
        </div>

        {/* Right: Demo Credentials Panel */}
        <div className="hidden lg:flex flex-col justify-center">
          <div
            className="rounded-3xl p-6"
            style={{
              background: 'rgba(255,255,255,0.02)',
              border: '1px solid rgba(255,255,255,0.06)',
              backdropFilter: 'blur(24px)',
              boxShadow: '0 32px 80px rgba(0,0,0,0.5)',
            }}
          >
            {/* Header */}
            <div className="flex items-center gap-2 mb-6">
              <div
                className="w-2 h-2 rounded-full"
                style={{
                  background: '#D4AF37',
                  boxShadow: '0 0 8px rgba(212,175,55,0.8)',
                  animation: 'pulse 2s infinite',
                }}
              />
              <span className="text-xs font-semibold tracking-widest uppercase text-white/40">
                Demo Access Credentials
              </span>
            </div>

            <h2 className="text-xl font-bold text-white mb-1">Quick Access</h2>
            <p className="text-sm text-white/30 mb-6">Click any role to auto-fill credentials</p>

            <div className="flex flex-col gap-3">
              {demoUsers.map((user) => (
                <button
                  key={user.role}
                  onClick={() => fillCredentials(user)}
                  className="w-full text-left rounded-2xl p-4 transition-all group relative overflow-hidden"
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.06)',
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.border =
                      `1px solid ${user.color}30`;
                    (e.currentTarget as HTMLButtonElement).style.background =
                      `rgba(255,255,255,0.05)`;
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.border =
                      '1px solid rgba(255,255,255,0.06)';
                    (e.currentTarget as HTMLButtonElement).style.background =
                      'rgba(255,255,255,0.03)';
                  }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {/* Role avatar */}
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold text-black flex-shrink-0"
                        style={{
                          background: `linear-gradient(135deg, ${user.color}, ${user.color}99)`,
                        }}
                      >
                        {user.role.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-semibold text-white">{user.role}</span>
                          <span
                            className="text-[10px] font-medium px-2 py-0.5 rounded-full"
                            style={{
                              background: `${user.color}15`,
                              color: user.color,
                              border: `1px solid ${user.color}30`,
                            }}
                          >
                            {user.badge}
                          </span>
                        </div>
                        <p className="text-[11px] text-white/30 font-mono">{user.email}</p>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        copyToClipboard(user.email, user.email);
                      }}
                      className="flex-shrink-0 p-1.5 rounded-lg transition-colors"
                      style={{
                        color: copiedEmail === user.email ? '#D4AF37' : 'rgba(255,255,255,0.2)',
                      }}
                    >
                      {copiedEmail === user.email ? <Check size={13} /> : <Copy size={13} />}
                    </button>
                  </div>
                </button>
              ))}
            </div>

            {/* Ambassador special badge */}
            <div
              className="mt-4 rounded-2xl p-4"
              style={{
                background: 'rgba(212,175,55,0.05)',
                border: '1px solid rgba(212,175,55,0.15)',
              }}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                <span className="text-xs font-semibold text-[#D4AF37] tracking-widest uppercase">
                  Ambassador Referral Code
                </span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <code className="text-lg font-bold text-white tracking-widest">VYSHNAVI2026</code>
                <button
                  onClick={() => copyToClipboard('VYSHNAVI2026', 'ref')}
                  className="p-2 rounded-lg transition-colors"
                  style={{ color: copiedEmail === 'ref' ? '#D4AF37' : 'rgba(255,255,255,0.3)' }}
                >
                  {copiedEmail === 'ref' ? <Check size={14} /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            {/* Seed Button */}
            <button
              onClick={() => void seedDemo()}
              disabled={seeding || seedDone}
              className="mt-4 w-full h-10 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all"
              style={{
                background: seedDone ? 'rgba(16,185,129,0.1)' : 'rgba(212,175,55,0.08)',
                border: seedDone
                  ? '1px solid rgba(16,185,129,0.3)'
                  : '1px solid rgba(212,175,55,0.2)',
                color: seedDone ? '#10B981' : '#D4AF37',
                cursor: seeding || seedDone ? 'not-allowed' : 'pointer',
              }}
            >
              {seeding ? (
                <span className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full border-2 border-current/20 border-t-current"
                    style={{ animation: 'spin 0.8s linear infinite' }}
                  />
                  Initializing users…
                </span>
              ) : seedDone ? (
                '✓ Demo users initialized!'
              ) : (
                '⚡ Initialize Demo Users'
              )}
            </button>
          </div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes floatBlob1 {
          0%,
          100% {
            transform: translate(0, 0) scale(1);
          }
          50% {
            transform: translate(30px, 20px) scale(1.05);
          }
        }
        @keyframes floatBlob2 {
          0%,
          100% {
            transform: translate(0, 0) scale(1);
          }
          50% {
            transform: translate(-20px, -30px) scale(1.03);
          }
        }
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
        @keyframes pulse {
          0%,
          100% {
            opacity: 1;
          }
          50% {
            opacity: 0.4;
          }
        }
      `}</style>
    </main>
  );
}

export default function SignInPage() {
  return (
    <Suspense>
      <SignInForm />
    </Suspense>
  );
}
