'use client';

import React, { useState } from 'react';
import {
  MessageSquare,
  Send,
  Mail,
  MessageCircle,
  Bell,
  Clock,
  CheckCircle2,
  Filter,
  ChevronRight,
  Users,
  Zap,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

const notifications = [
  {
    id: 1,
    type: 'signup',
    user: 'TechNova',
    message: 'New lead signed up for Saasum AI via Gateway.',
    time: '2m ago',
    read: false,
  },
  {
    id: 2,
    type: 'deal',
    user: 'FutureHire',
    message: 'Deal for Hiring Pipeline moved to Won.',
    time: '1h ago',
    read: true,
  },
  {
    id: 3,
    type: 'referral',
    user: 'James Wilson',
    message: 'New referral conversion detected from Instagram.',
    time: '3h ago',
    read: false,
  },
  {
    id: 4,
    type: 'invoice',
    user: 'EduGlobal',
    message: 'Invoice INV-92837 marked as Overdue.',
    time: '5h ago',
    read: true,
  },
];

export default function CommunicationCenter() {
  const [activeTab, setActiveTab] = useState('notifications');
  const [recipient, setRecipient] = useState('');
  const [message, setMessage] = useState('');

  const handleSend = (type: 'email' | 'telegram') => {
    if (!recipient || !message) {
      toast.error('Please fill in both recipient and message');
      return;
    }
    toast.success(`${type === 'email' ? 'Email' : 'Telegram message'} sent to ${recipient}`);
    setRecipient('');
    setMessage('');
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold tracking-tight">
          Communication <span className="text-[#D4AF37]">Center</span>
        </h1>
        <p className="text-white/40">Unified messaging for the Centle Group ecosystem.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Tabs defaultValue="notifications" className="w-full" onValueChange={setActiveTab}>
            <TabsList className="bg-white/5 border-white/10 p-1 rounded-xl h-12 w-full max-w-md">
              <TabsTrigger
                value="notifications"
                className="rounded-lg data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black transition-all flex-1"
              >
                <Bell size={14} className="mr-2" /> Notifications
              </TabsTrigger>
              <TabsTrigger
                value="history"
                className="rounded-lg data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black transition-all flex-1"
              >
                <Clock size={14} className="mr-2" /> History
              </TabsTrigger>
            </TabsList>

            <TabsContent value="notifications" className="mt-8 space-y-4">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold">Recent Updates</h3>
                <Button variant="ghost" className="text-xs text-[#D4AF37] font-bold">
                  Mark all as read
                </Button>
              </div>

              <AnimatePresence>
                {notifications.map((n, i) => (
                  <motion.div
                    key={n.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <Card
                      className={cn(
                        'bg-white/5 border-white/5 hover:border-white/10 transition-all cursor-pointer group',
                        !n.read && 'border-[#D4AF37]/20 bg-[#D4AF37]/5'
                      )}
                    >
                      <CardContent className="p-4 flex items-center gap-4">
                        <div
                          className={cn(
                            'w-10 h-10 rounded-xl flex items-center justify-center shrink-0',
                            n.type === 'signup'
                              ? 'bg-blue-500/10 text-blue-400'
                              : n.type === 'deal'
                                ? 'bg-green-500/10 text-green-400'
                                : n.type === 'referral'
                                  ? 'bg-[#D4AF37]/10 text-[#D4AF37]'
                                  : 'bg-red-500/10 text-red-400'
                          )}
                        >
                          {n.type === 'signup' ? (
                            <Users size={18} />
                          ) : n.type === 'deal' ? (
                            <CheckCircle2 size={18} />
                          ) : n.type === 'referral' ? (
                            <Zap size={18} />
                          ) : (
                            <AlertCircle size={18} />
                          )}
                        </div>
                        <div className="flex-1 overflow-hidden">
                          <div className="flex justify-between items-start">
                            <p className="font-bold text-sm">{n.user}</p>
                            <span className="text-[10px] text-white/30">{n.time}</span>
                          </div>
                          <p className="text-xs text-white/50 truncate pr-4">{n.message}</p>
                        </div>
                        <ChevronRight
                          size={14}
                          className="text-white/10 group-hover:text-white transition-colors"
                        />
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </TabsContent>

            <TabsContent value="history" className="mt-8">
              <Card className="bg-white/5 border-white/5 p-12 text-center">
                <Clock size={40} className="text-white/10 mx-auto mb-4" />
                <h3 className="font-bold text-white/60">No communication history</h3>
                <p className="text-xs text-white/40 mt-2">
                  Past emails and Telegram logs will appear here.
                </p>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-8">
          <Card className="bg-white/5 border-white/5 border-t-2 border-t-[#D4AF37]/50">
            <CardHeader>
              <CardTitle>Quick Dispatch</CardTitle>
              <CardDescription>Send automated messages to ecosystem leads.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">
                  Recipient
                </label>
                <Input
                  placeholder="Email or Telegram handle"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  className="bg-black/20 border-white/5 focus:border-[#D4AF37]/30 h-11 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">
                  Message
                </label>
                <textarea
                  placeholder="Type your automated message..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-black/20 border border-white/5 focus:border-[#D4AF37]/30 rounded-xl p-4 text-sm min-h-[120px] outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={() => handleSend('email')}
                  className="bg-white/5 hover:bg-white/10 text-white font-bold h-11 rounded-xl flex items-center gap-2"
                >
                  <Mail size={16} /> Email
                </Button>
                <Button
                  onClick={() => handleSend('telegram')}
                  className="bg-[#24A1DE]/10 hover:bg-[#24A1DE]/20 text-[#24A1DE] font-bold h-11 rounded-xl flex items-center gap-2"
                >
                  <MessageCircle size={16} /> Telegram
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[#D4AF37]/10 to-transparent border-[#D4AF37]/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <Zap size={16} className="text-[#D4AF37]" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  Active Automation
                </span>
              </div>
              <h4 className="font-bold mb-2">CRM Webhook Pulse</h4>
              <p className="text-xs text-white/40 mb-6">
                Gateway leads are automatically receiving "Welcome" sequences across email and
                Telegram.
              </p>
              <div className="flex items-center gap-2 text-[10px] text-green-400 font-bold bg-green-500/10 px-3 py-1 rounded-full w-fit">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" /> SYSTEM
                ACTIVE
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

const cn = (...inputs: any[]) => inputs.filter(Boolean).join(' ');

function AlertCircle(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}
