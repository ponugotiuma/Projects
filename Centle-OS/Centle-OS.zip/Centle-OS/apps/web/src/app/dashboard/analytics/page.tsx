'use client';

import React from 'react';
import {
  Brain,
  Sparkles,
  Zap,
  Target,
  TrendingUp,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  ZapOff,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';

export default function AIInsightsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold tracking-tight">
          AI <span className="text-[#D4AF37]">Insights</span>
        </h1>
        <p className="text-white/40">Ecosystem-wide predictive analytics and recommendations.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 bg-gradient-to-br from-[#D4AF37]/10 to-transparent border-[#D4AF37]/20 overflow-hidden relative group">
          <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:opacity-10 transition-opacity">
            <Brain size={200} className="text-[#D4AF37]" />
          </div>
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="text-[#D4AF37] w-5 h-5" />
              <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#D4AF37]">
                Next Best Actions
              </span>
            </div>
            <CardTitle className="text-3xl font-bold">Predictive Strategy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {[
              {
                title: 'Accelerate Saasum AI Pipeline',
                desc: 'Leads from "Company + Technology" routing are converting 40% faster. Increase ad spend on LinkedIn by 15%.',
                impact: 'High',
              },
              {
                title: 'Upsell Skill Tank to Promtal Leads',
                desc: '72% of candidates hired via Promtal require Python training. Automated cross-venture sequence recommended.',
                impact: 'Medium',
              },
              {
                title: 'Optimize Vriddhi Referral Payouts',
                desc: 'Current commission rates for "Financial Research" are 5% below market. Adjustment will likely increase volume by 25%.',
                impact: 'High',
              },
            ].map((action, i) => (
              <div
                key={i}
                className="flex items-start gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-[#D4AF37]/30 transition-all cursor-pointer"
              >
                <div className="p-2 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37]">
                  <Lightbulb size={20} />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="font-bold text-sm">{action.title}</h4>
                    <Badge
                      variant="outline"
                      className={cn(
                        'text-[10px] px-2 py-0',
                        action.impact === 'High'
                          ? 'border-green-500/30 text-green-400'
                          : 'border-yellow-500/30 text-yellow-400'
                      )}
                    >
                      {action.impact} Impact
                    </Badge>
                  </div>
                  <p className="text-xs text-white/50">{action.desc}</p>
                </div>
                <ArrowRight size={16} className="text-white/20 self-center" />
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="space-y-8">
          <Card className="bg-white/5 border-white/5">
            <CardHeader>
              <CardTitle>Lead Scoring Model</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-white/40">Data Quality</span>
                  <span className="font-bold text-green-400">98%</span>
                </div>
                <Progress value={98} className="h-1.5 bg-white/5" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-white/40">Prediction Accuracy</span>
                  <span className="font-bold text-[#D4AF37]">84%</span>
                </div>
                <Progress value={84} className="h-1.5 bg-white/5" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-white/40">Ecosystem Routing Health</span>
                  <span className="font-bold text-blue-400">Optimal</span>
                </div>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex-1 h-1.5 rounded-full bg-blue-500" />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#D4AF37]/5 border-[#D4AF37]/10">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <ShieldCheck size={16} className="text-[#D4AF37]" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  Security Scan
                </span>
              </div>
              <h4 className="font-bold mb-2">Fraud Detection Active</h4>
              <p className="text-xs text-white/40 mb-6">
                AI is monitoring referral clicks for sybil attacks. No suspicious activity detected
                in last 24h.
              </p>
              <div className="flex items-center gap-2 text-[10px] text-green-400 font-bold bg-green-500/10 px-3 py-1 rounded-full w-fit">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" /> SCANNING
                LIVE
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

const cn = (...inputs: any[]) => inputs.filter(Boolean).join(' ');

function Badge({ children, className, variant = 'default' }: any) {
  return (
    <div
      className={cn(
        'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2',
        variant === 'outline' ? 'text-white' : 'bg-white text-black',
        className
      )}
    >
      {children}
    </div>
  );
}
