'use client';

import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  FileText,
  Plus,
  Search,
  Download,
  MoreVertical,
  CheckCircle2,
  Clock,
  AlertCircle,
  TrendingUp,
  DollarSign,
  Receipt,
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

const statusColors: any = {
  draft: 'bg-white/5 text-white/40 border-white/10',
  sent: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  paid: 'bg-green-500/10 text-green-400 border-green-500/20',
  overdue: 'bg-red-500/10 text-red-400 border-red-500/20',
};

export default function ERPPage() {
  const queryClient = useQueryClient();
  const { data: invoices, isLoading } = useQuery({
    queryKey: ['invoices'],
    queryFn: async () => {
      const res = await fetch('/api/invoices');
      if (!res.ok) throw new Error('Failed to fetch invoices');
      return res.json();
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      // Mock update
      toast.success(`Invoice ${id} marked as ${status}`);
    },
  });

  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const formatDate = (dateString: string) => {
    return dateString?.split('T')[0] || ''; // Stable string manipulation
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">
            ERP & <span className="text-[#D4AF37]">Invoicing</span>
          </h1>
          <p className="text-white/40">Manage financial ecosystem operations.</p>
        </div>
        <div className="flex gap-3">
          <Button className="bg-[#D4AF37] hover:bg-[#C5A028] text-black font-bold rounded-xl px-6">
            <Receipt className="mr-2 w-4 h-4" /> New Invoice
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { title: 'Total Invoiced', value: '$242,500', icon: DollarSign, color: 'gold' },
          { title: 'Paid', value: '$182,000', icon: CheckCircle2, color: 'green' },
          { title: 'Pending', value: '$45,500', icon: Clock, color: 'blue' },
          { title: 'Overdue', value: '$15,000', icon: AlertCircle, color: 'red' },
        ].map((stat, i) => (
          <Card key={i} className="bg-white/5 border-white/5 p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-white/5 text-[#D4AF37]">
                <stat.icon size={20} />
              </div>
              <div>
                <p className="text-white/40 text-xs">{stat.title}</p>
                <p className="text-xl font-bold">{stat.value}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="bg-white/5 border-white/5 p-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4 bg-black/20 px-3 py-2 rounded-lg border border-white/5 flex-1 max-w-md">
          <Search size={16} className="text-white/30" />
          <input
            type="text"
            placeholder="Search invoice number, client..."
            className="bg-transparent border-none outline-none text-sm placeholder:text-white/20 w-full"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" className="text-xs text-white/40 hover:text-white">
            Export
          </Button>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/5 overflow-hidden">
        <Table>
          <TableHeader className="bg-white/[0.02]">
            <TableRow className="border-white/5 hover:bg-transparent">
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Invoice
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Venture / Deal
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Amount
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Status
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Due Date
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4 text-right">
                Actions
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading
              ? Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i} className="border-white/5">
                    <TableCell>
                      <Skeleton className="h-4 w-24 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-32 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-16 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-16 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-20 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-8 ml-auto bg-white/5" />
                    </TableCell>
                  </TableRow>
                ))
              : invoices?.map((invoice: any) => (
                  <TableRow
                    key={invoice.id}
                    className="border-white/5 hover:bg-white/[0.02] transition-colors group"
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <FileText size={14} className="text-[#D4AF37]" />
                        <span className="font-mono text-xs font-bold text-white/90">
                          {invoice.invoice_number}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm font-medium text-white/80">{invoice.deal_name}</p>
                        <p className="text-[10px] text-[#D4AF37] font-bold uppercase">
                          {invoice.venture_name}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-bold text-white/90">
                          ${Number(invoice.amount).toLocaleString()}
                        </p>
                        {invoice.discount_percent > 0 && (
                          <p className="text-[10px] text-green-400">
                            -{invoice.discount_percent}% Discount
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={cn('border', statusColors[invoice.status] || 'bg-white/5')}>
                        {invoice.status.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-white/40 text-xs" suppressHydrationWarning>
                      {formatDate(invoice.created_at)}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            className="h-8 w-8 p-0 text-white/40 hover:text-white"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent
                          align="end"
                          className="bg-[#0A0A0A] border-white/10 text-white"
                        >
                          <DropdownMenuItem className="hover:bg-white/5 cursor-pointer">
                            <Download className="mr-2 w-4 h-4" /> Download PDF
                          </DropdownMenuItem>
                          <DropdownMenuItem className="hover:bg-white/5 cursor-pointer">
                            Mark as Paid
                          </DropdownMenuItem>
                          <DropdownMenuItem className="hover:bg-white/5 cursor-pointer text-red-400">
                            Cancel
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
            {!isLoading && (!invoices || invoices.length === 0) && (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-white/20 text-sm">
                  No invoices generated yet.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
