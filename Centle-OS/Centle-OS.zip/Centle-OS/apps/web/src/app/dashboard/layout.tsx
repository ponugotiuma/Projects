'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Users,
  Briefcase,
  FileText,
  Settings,
  LogOut,
  Bell,
  Search,
  ChevronLeft,
  ChevronRight,
  PieChart,
  Zap,
  Target,
  MessageSquare,
  Crown,
  Shield,
  Star,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { authClient } from '@/lib/auth-client';

const roleMap: Record<string, { label: string; badge: string; color: string; icon: typeof Crown }> =
  {
    'vamshi.admin-centleos@gmail.com': {
      label: 'Vamshi Krishna',
      badge: 'Global Admin',
      color: '#D4AF37',
      icon: Crown,
    },
    'saikrishna.manager-centleos@gmail.com': {
      label: 'Sai Krishna',
      badge: 'Manager',
      color: '#A8D8A8',
      icon: Briefcase,
    },
    'pavani.ops-centleos@gmail.com': {
      label: 'Pavani',
      badge: 'Operations',
      color: '#87CEEB',
      icon: Settings,
    },
    'priya.sales-centleos@gmail.com': {
      label: 'Priya',
      badge: 'Sales Rep',
      color: '#DDA0DD',
      icon: Target,
    },
    'vyshnavi.ambassador-centleos@gmail.com': {
      label: 'Vyshnavi',
      badge: 'Ambassador',
      color: '#F4A460',
      icon: Star,
    },
  };

const allNavItems = [
  {
    name: 'Executive Summary',
    icon: LayoutDashboard,
    href: '/dashboard',
    roles: ['admin', 'manager'],
  },
  {
    name: 'Lead Management',
    icon: Users,
    href: '/dashboard/leads',
    roles: ['admin', 'manager', 'sales', 'operations'],
  },
  {
    name: 'Deal Pipeline',
    icon: Target,
    href: '/dashboard/deals',
    roles: ['admin', 'manager', 'sales'],
  },
  {
    name: 'ERP & Invoicing',
    icon: FileText,
    href: '/dashboard/erp',
    roles: ['admin', 'operations'],
  },
  {
    name: 'Referral Center',
    icon: Zap,
    href: '/dashboard/referrals',
    roles: ['admin', 'ambassador', 'manager'],
  },
  {
    name: 'Communication',
    icon: MessageSquare,
    href: '/dashboard/communications',
    roles: ['admin', 'manager', 'operations'],
  },
  { name: 'Analytics', icon: PieChart, href: '/dashboard/analytics', roles: ['admin', 'manager'] },
  { name: 'Settings', icon: Settings, href: '/dashboard/settings', roles: ['admin'] },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [seeded, setSeeded] = useState(false);
  const pathname = usePathname();
  const { data: session } = authClient.useSession();

  const userEmail = session?.user?.email ?? '';
  const userInfo = roleMap[userEmail] ?? {
    label: session?.user?.name ?? 'User',
    badge: 'Member',
    color: '#D4AF37',
    icon: Shield,
  };

  // Determine role from email for nav filtering
  const getRoleKey = (email: string) => {
    if (email.includes('admin')) return 'admin';
    if (email.includes('manager')) return 'manager';
    if (email.includes('ops')) return 'operations';
    if (email.includes('sales')) return 'sales';
    if (email.includes('ambassador')) return 'ambassador';
    return 'admin'; // default — show all
  };

  const roleKey = getRoleKey(userEmail);
  const navItems = allNavItems.filter((item) => item.roles.includes(roleKey));

  // Auto-seed on first load
  useEffect(() => {
    if (!seeded) {
      setSeeded(true);
      fetch('/api/seed')
        .then((r) => r.json())
        .then((data) => {
          if (data.users === 0) {
            fetch('/api/seed', { method: 'POST' }).catch(console.error);
          }
        })
        .catch(console.error);
    }
  }, [seeded]);

  const UserIcon = userInfo.icon;

  return (
    <div className="min-h-screen bg-[#050505] text-white flex overflow-hidden">
      {/* Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: isCollapsed ? 80 : 280 }}
        className="relative z-50 flex flex-col border-r border-white/5 bg-[#0A0A0A]/80 backdrop-blur-xl transition-all duration-300"
      >
        <div className="p-6 flex items-center justify-between">
          {!isCollapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-lg bg-[#D4AF37] flex items-center justify-center">
                <Zap className="text-black w-5 h-5 fill-current" />
              </div>
              <span className="font-bold text-xl tracking-tight">
                Centle <span className="text-[#D4AF37]">OS</span>
              </span>
            </motion.div>
          )}
          {isCollapsed && (
            <div className="w-8 h-8 rounded-lg bg-[#D4AF37] flex items-center justify-center mx-auto">
              <Zap className="text-black w-5 h-5 fill-current" />
            </div>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="hidden md:flex absolute -right-3 top-20 w-6 h-6 rounded-full bg-[#1A1A1A] border border-white/10 items-center justify-center hover:border-[#D4AF37]/50 transition-colors z-50"
          >
            {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>
        </div>

        <nav className="flex-1 px-3 mt-8 space-y-1">
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-300 group relative',
                  isActive
                    ? 'bg-[#D4AF37]/10 text-[#D4AF37]'
                    : 'text-white/40 hover:text-white hover:bg-white/5'
                )}
              >
                <item.icon
                  className={cn('w-5 h-5', isActive ? 'text-[#D4AF37]' : 'group-hover:text-white')}
                />
                {!isCollapsed && <span className="text-sm font-medium">{item.name}</span>}
                {isActive && (
                  <motion.div
                    layoutId="active-pill"
                    className="absolute left-0 w-1 h-6 bg-[#D4AF37] rounded-r-full"
                  />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/5">
          <div
            className={cn('flex items-center gap-3 mb-4', isCollapsed ? 'justify-center' : 'px-3')}
          >
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold text-black"
              style={{
                background: `linear-gradient(135deg, ${userInfo.color}, ${userInfo.color}99)`,
              }}
            >
              {!isCollapsed ? (
                <UserIcon size={16} className="text-black" />
              ) : (
                <span>{userInfo.label.substring(0, 1)}</span>
              )}
            </div>
            {!isCollapsed && (
              <div className="flex-1 overflow-hidden">
                <p className="text-sm font-semibold text-white truncate">{userInfo.label}</p>
                <p
                  className="text-[10px] font-bold tracking-widest uppercase truncate"
                  style={{ color: userInfo.color }}
                >
                  {userInfo.badge}
                </p>
              </div>
            )}
          </div>
          <Link
            href="/account/logout"
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-xl text-white/30 hover:text-red-400 hover:bg-red-400/5 transition-all text-sm',
              isCollapsed && 'justify-center'
            )}
          >
            <LogOut className="w-4 h-4" />
            {!isCollapsed && <span className="font-medium">Sign Out</span>}
          </Link>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-white/5 bg-[#0A0A0A]/50 backdrop-blur-md flex items-center justify-between px-8 z-40">
          <div className="flex items-center gap-4 bg-white/5 px-4 py-2 rounded-xl border border-white/5 focus-within:border-[#D4AF37]/30 transition-all">
            <Search className="w-4 h-4 text-white/30" />
            <input
              type="text"
              placeholder="Search leads, deals, or invoices..."
              className="bg-transparent border-none outline-none text-sm w-64 placeholder:text-white/20"
            />
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 rounded-lg hover:bg-white/5 transition-colors">
              <Bell className="w-5 h-5 text-white/40" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-[#D4AF37] rounded-full border border-[#0A0A0A]" />
            </button>
            <div className="h-8 w-[1px] bg-white/5" />
            <div className="text-right hidden sm:block">
              <p className="text-xs font-semibold text-white/80">
                {userInfo.label || 'Executive Portal'}
              </p>
              <p
                className="text-[10px] font-bold tracking-widest uppercase"
                style={{ color: userInfo.color }}
              >
                {userInfo.badge}
              </p>
            </div>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-black text-xs font-bold"
              style={{
                background: `linear-gradient(135deg, ${userInfo.color}, ${userInfo.color}99)`,
              }}
            >
              <UserIcon size={14} className="text-black" />
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto bg-[#050505] relative custom-scrollbar">
          <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-[#D4AF37]/5 to-transparent pointer-events-none" />
          <div className="p-8 max-w-7xl mx-auto relative z-10">{children}</div>
        </div>
      </main>

      <style jsx global>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(212, 175, 55, 0.2);
        }
      `}</style>
    </div>
  );
}
