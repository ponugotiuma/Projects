'use client';

import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Plus,
  Search,
  Filter,
  MoreVertical,
  Mail,
  Phone,
  ExternalLink,
  Brain,
  TrendingUp,
  Clock,
  CheckCircle2,
  Users,
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { cn } from '@/lib/utils';

const statusColors: any = {
  new: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  contacted: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  qualified: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  proposal: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
  negotiation: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  won: 'bg-green-500/10 text-green-400 border-green-500/20',
  lost: 'bg-red-500/10 text-red-400 border-red-500/20',
};

export default function LeadsPage() {
  const { data: leads, isLoading } = useQuery({
    queryKey: ['leads'],
    queryFn: async () => {
      const res = await fetch('/api/leads');
      if (!res.ok) throw new Error('Failed to fetch leads');
      return res.json();
    },
  });

  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const formatDate = (dateString: string) => {
    return dateString?.split('T')[0] || ''; // Stable string manipulation
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">
            Lead <span className="text-[#D4AF37]">Management</span>
          </h1>
          <p className="text-white/40">Track and nurture ecosystem opportunities.</p>
        </div>
        <div className="flex gap-3">
          <Button className="bg-[#D4AF37] hover:bg-[#C5A028] text-black font-bold rounded-xl px-6">
            <Plus className="mr-2 w-4 h-4" /> Add Manual Lead
          </Button>
        </div>
      </div>

      {/* Analytics Overview for Leads */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white/5 border-white/5 p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400">
              <Users size={20} />
            </div>
            <div>
              <p className="text-white/40 text-xs">Total Pipeline</p>
              <p className="text-2xl font-bold">1,248</p>
            </div>
          </div>
        </Card>
        <Card className="bg-white/5 border-white/5 p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-[#D4AF37]/10 text-[#D4AF37]">
              <Brain size={20} />
            </div>
            <div>
              <p className="text-white/40 text-xs">AI Qualified</p>
              <p className="text-2xl font-bold">482</p>
            </div>
          </div>
        </Card>
        <Card className="bg-white/5 border-white/5 p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-green-500/10 text-green-400">
              <TrendingUp size={20} />
            </div>
            <div>
              <p className="text-white/40 text-xs">Avg. Score</p>
              <p className="text-2xl font-bold">78/100</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Filter Bar */}
      <Card className="bg-white/5 border-white/5 p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="flex items-center gap-2 bg-black/20 px-3 py-2 rounded-lg border border-white/5 flex-1 md:flex-none">
            <Search size={16} className="text-white/30" />
            <input
              type="text"
              placeholder="Search leads..."
              className="bg-transparent border-none outline-none text-sm placeholder:text-white/20"
            />
          </div>
          <Button
            variant="ghost"
            className="text-white/60 hover:text-white hover:bg-white/5 text-sm"
          >
            <Filter size={16} className="mr-2" /> Filters
          </Button>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" className="text-xs text-[#D4AF37] font-bold">
            Download CSV
          </Button>
        </div>
      </Card>

      {/* Table */}
      <Card className="bg-white/5 border-white/5 overflow-hidden">
        <Table>
          <TableHeader className="bg-white/[0.02]">
            <TableRow className="border-white/5 hover:bg-transparent">
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Lead Details
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Venture
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Status
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4 text-center">
                AI Score
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4">
                Created
              </TableHead>
              <TableHead className="text-white/40 font-bold uppercase text-[10px] tracking-wider py-4 text-right">
                Actions
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading
              ? Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i} className="border-white/5">
                    <TableCell>
                      <Skeleton className="h-4 w-32 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-20 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-16 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-10 mx-auto bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-24 bg-white/5" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-8 ml-auto bg-white/5" />
                    </TableCell>
                  </TableRow>
                ))
              : leads?.map((lead: any) => (
                  <TableRow
                    key={lead.id}
                    className="border-white/5 hover:bg-white/[0.02] transition-colors group"
                  >
                    <TableCell>
                      <div>
                        <p className="font-bold text-white/90">{lead.contact_name}</p>
                        <p className="text-[10px] text-white/40">{lead.company_name}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className="border-white/10 bg-white/5 text-white/60 font-medium"
                      >
                        {lead.venture_name || 'Centle OS'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={cn('border', statusColors[lead.status] || 'bg-white/5')}>
                        {lead.status.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="inline-flex flex-col items-center">
                        <span
                          className={cn(
                            'text-sm font-bold',
                            lead.lead_score > 80
                              ? 'text-green-400'
                              : lead.lead_score > 60
                                ? 'text-[#D4AF37]'
                                : 'text-red-400'
                          )}
                        >
                          {lead.lead_score}
                        </span>
                        <div className="w-12 h-1 bg-white/5 rounded-full mt-1 overflow-hidden">
                          <div
                            className="h-full bg-[#D4AF37]"
                            style={{ width: `${lead.lead_score}%` }}
                          />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-white/40 text-xs" suppressHydrationWarning>
                      {formatDate(lead.created_at)}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            className="h-8 w-8 p-0 text-white/40 hover:text-white"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent
                          align="end"
                          className="bg-[#0A0A0A] border-white/10 text-white"
                        >
                          <DropdownMenuItem className="hover:bg-white/5 cursor-pointer">
                            View Detail
                          </DropdownMenuItem>
                          <DropdownMenuItem className="hover:bg-white/5 cursor-pointer">
                            Move Stage
                          </DropdownMenuItem>
                          <DropdownMenuItem className="hover:bg-white/5 cursor-pointer text-red-400">
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
