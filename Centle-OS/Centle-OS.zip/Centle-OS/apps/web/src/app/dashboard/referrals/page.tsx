'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Zap,
  Copy,
  Share2,
  Users,
  Target,
  DollarSign,
  ExternalLink,
  Award,
  CheckCircle2,
  Clock,
  ArrowUpRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function ReferralCenterPage() {
  const queryClient = useQueryClient();
  const [isCopying, setIsCopying] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['referrals'],
    queryFn: async () => {
      const res = await fetch('/api/referrals');
      if (!res.ok) throw new Error('Failed to fetch referrals');
      return res.json();
    },
  });

  const createCodeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/referrals', { method: 'POST' });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['referrals'] });
      toast.success('Referral code generated!');
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopying(true);
    toast.success('Link copied to clipboard');
    setTimeout(() => setIsCopying(false), 2000);
  };

  const referralLink = data?.referralCode
    ? `${window.location.origin}/?ref=${data.referralCode.code}`
    : '';

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold tracking-tight">
          Referral <span className="text-[#D4AF37]">Center</span>
        </h1>
        <p className="text-white/40">Scale the ecosystem and earn commissions.</p>
      </div>

      {!data?.referralCode && !isLoading ? (
        <Card className="bg-[#D4AF37]/5 border-[#D4AF37]/20 p-12 text-center">
          <div className="w-20 h-20 rounded-full bg-[#D4AF37]/10 flex items-center justify-center mx-auto mb-6">
            <Zap className="text-[#D4AF37] w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Become an Ambassador</h2>
          <p className="text-white/60 mb-8 max-w-md mx-auto">
            Join the elite circle of Centle Group ambassadors. Generate your unique code and start
            tracking your impact.
          </p>
          <Button
            onClick={() => createCodeMutation.mutate()}
            disabled={createCodeMutation.isPending}
            className="bg-[#D4AF37] hover:bg-[#C5A028] text-black font-bold h-12 px-8 rounded-xl"
          >
            {createCodeMutation.isPending ? 'Generating...' : 'Generate My Code'}
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <Card className="bg-white/5 border-white/5 overflow-hidden group">
              <CardHeader className="border-b border-white/5">
                <CardTitle className="flex items-center gap-2">
                  <Award className="text-[#D4AF37] w-5 h-5" />
                  Your Ambassador Portal
                </CardTitle>
                <CardDescription>
                  Share your unique link to track leads and conversions.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex-1 space-y-4">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">
                      Your Referral Link
                    </label>
                    <div className="flex items-center gap-2 bg-black/40 p-1 pl-4 rounded-xl border border-white/5">
                      <span className="text-sm font-mono text-white/60 truncate flex-1">
                        {referralLink}
                      </span>
                      <Button
                        size="sm"
                        onClick={() => copyToClipboard(referralLink)}
                        className="bg-white/5 hover:bg-white/10 text-white rounded-lg h-10 px-4"
                      >
                        {isCopying ? <CheckCircle2 size={16} /> : <Copy size={16} />}
                      </Button>
                    </div>
                  </div>
                  <div className="w-full md:w-32 flex flex-col justify-end">
                    <Button
                      variant="outline"
                      className="border-white/10 hover:bg-white/5 text-white h-12 w-full rounded-xl"
                    >
                      <Share2 size={16} className="mr-2" /> Share
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  title: 'Total Clicks',
                  value: data?.stats?.total_clicks || 0,
                  icon: Users,
                  color: 'blue',
                },
                {
                  title: 'Total Leads',
                  value: data?.stats?.total_leads || 0,
                  icon: Target,
                  color: 'purple',
                },
                {
                  title: 'Conversions',
                  value: data?.stats?.total_deals || 0,
                  icon: Zap,
                  color: 'gold',
                },
                {
                  title: 'Pending Payout',
                  value: `$${(data?.stats?.total_revenue * 0.1 || 0).toFixed(2)}`,
                  icon: DollarSign,
                  color: 'green',
                },
              ].map((stat, i) => (
                <Card key={i} className="bg-white/5 border-white/5 p-6 group">
                  <div className="flex justify-between items-center mb-4">
                    <div className="p-3 rounded-xl bg-white/5 text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-black transition-all">
                      <stat.icon size={20} />
                    </div>
                    <ArrowUpRight
                      size={16}
                      className="text-white/20 group-hover:text-[#D4AF37] transition-all"
                    />
                  </div>
                  <p className="text-white/40 text-xs font-medium mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold tracking-tight">{stat.value}</p>
                </Card>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <Card className="bg-white/5 border-white/5">
              <CardHeader>
                <CardTitle>Commission Structure</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { level: 'Tier 1', rate: '10%', requirement: '0 - 10 Conversions' },
                  { level: 'Tier 2', rate: '15%', requirement: '11 - 50 Conversions' },
                  { level: 'Tier 3', rate: '20%', requirement: '50+ Conversions' },
                ].map((tier, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/5"
                  >
                    <div>
                      <p className="font-bold text-sm">{tier.level}</p>
                      <p className="text-[10px] text-white/40">{tier.requirement}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[#D4AF37] font-bold">{tier.rate}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-[#D4AF37]/5 border-[#D4AF37]/10 overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Clock size={16} className="text-[#D4AF37]" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
                    Next Payout
                  </span>
                </div>
                <h3 className="text-2xl font-bold mb-1">July 15, 2026</h3>
                <p className="text-xs text-white/40">
                  Payouts are processed automatically on the 15th of every month.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
