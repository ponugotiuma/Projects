'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Target,
  Plus,
  MoreVertical,
  Calendar,
  DollarSign,
  ChevronRight,
  Filter,
  Users,
  Layout,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const stages = [
  { id: 'new', name: 'New Leads' },
  { id: 'qualified', name: 'Qualified' },
  { id: 'proposal', name: 'Proposal' },
  { id: 'negotiation', name: 'Negotiation' },
  { id: 'won', name: 'Won' },
];

export default function DealsPage() {
  const [activeStage, setActiveStage] = useState('all');

  const { data: deals, isLoading } = useQuery({
    queryKey: ['deals'],
    queryFn: async () => {
      // For now returning mock deals until API is fully wired
      return [
        {
          id: '1',
          name: 'Enterprise AI Suite',
          value: 45000,
          status: 'proposal',
          venture: 'Saasum AI',
          company: 'TechNova',
          probability: 60,
        },
        {
          id: '2',
          name: 'Learning Portal v2',
          value: 12000,
          status: 'qualified',
          venture: 'Skill Tank',
          company: 'EduGlobal',
          probability: 40,
        },
        {
          id: '3',
          name: 'Hiring Pipeline',
          value: 8500,
          status: 'new',
          venture: 'Promtal',
          company: 'FutureHire',
          probability: 20,
        },
        {
          id: '4',
          name: 'Growth Package',
          value: 25000,
          status: 'negotiation',
          venture: 'Tobofu',
          company: 'Moderna',
          probability: 85,
        },
      ];
    },
  });

  const filteredDeals =
    activeStage === 'all' ? deals : deals?.filter((d: any) => d.status === activeStage);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">
            Deal <span className="text-[#D4AF37]">Pipeline</span>
          </h1>
          <p className="text-white/40">Convert ecosystem opportunities into revenue.</p>
        </div>
        <div className="flex gap-3">
          <Button className="bg-[#D4AF37] hover:bg-[#C5A028] text-black font-bold rounded-xl px-6">
            <Plus className="mr-2 w-4 h-4" /> Create Deal
          </Button>
        </div>
      </div>

      {/* Stage Selector Board */}
      <div className="flex gap-4 overflow-x-auto pb-4 custom-scrollbar">
        <button
          onClick={() => setActiveStage('all')}
          className={cn(
            'px-6 py-3 rounded-xl border transition-all whitespace-nowrap',
            activeStage === 'all'
              ? 'bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#D4AF37]'
              : 'bg-white/5 border-white/5 text-white/40 hover:text-white'
          )}
        >
          All Stages ({deals?.length || 0})
        </button>
        {stages.map((stage) => (
          <button
            key={stage.id}
            onClick={() => setActiveStage(stage.id)}
            className={cn(
              'px-6 py-3 rounded-xl border transition-all whitespace-nowrap',
              activeStage === stage.id
                ? 'bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#D4AF37]'
                : 'bg-white/5 border-white/5 text-white/40 hover:text-white'
            )}
          >
            {stage.name} ({deals?.filter((d: any) => d.status === stage.id).length || 0})
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredDeals?.map((deal: any) => (
          <motion.div
            key={deal.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-white/5 border-white/5 hover:border-[#D4AF37]/30 transition-all duration-300 group cursor-pointer overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start mb-2">
                  <Badge
                    variant="outline"
                    className="text-[10px] uppercase tracking-widest border-[#D4AF37]/30 text-[#D4AF37]"
                  >
                    {deal.venture}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-white/20 hover:text-white"
                  >
                    <MoreVertical size={14} />
                  </Button>
                </div>
                <CardTitle className="text-lg font-bold group-hover:text-[#D4AF37] transition-colors">
                  {deal.name}
                </CardTitle>
                <div className="flex items-center gap-2 text-white/40 text-xs">
                  <Users size={12} /> {deal.company}
                </div>
              </CardHeader>
              <CardContent className="space-y-6 pt-4">
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-white/40 text-[10px] uppercase font-bold tracking-widest">
                      Deal Value
                    </p>
                    <p className="text-xl font-bold">${deal.value.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white/40 text-[10px] uppercase font-bold tracking-widest">
                      Win Probability
                    </p>
                    <p
                      className={cn(
                        'text-sm font-bold',
                        deal.probability > 75
                          ? 'text-green-400'
                          : deal.probability > 40
                            ? 'text-[#D4AF37]'
                            : 'text-red-400'
                      )}
                    >
                      {deal.probability}%
                    </p>
                  </div>
                </div>

                <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-[#D4AF37]" style={{ width: `${deal.probability}%` }} />
                </div>

                <div className="flex justify-between items-center pt-2">
                  <div className="flex items-center gap-1 text-[10px] text-white/40">
                    <Calendar size={12} /> July 28, 2026
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 text-xs text-[#D4AF37] group-hover:bg-[#D4AF37]/10"
                  >
                    Details <ChevronRight size={14} />
                  </Button>
                </div>
              </CardContent>
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-[#D4AF37]/5 to-transparent pointer-events-none" />
            </Card>
          </motion.div>
        ))}
      </div>

      {!isLoading && (!filteredDeals || filteredDeals.length === 0) && (
        <div className="py-20 text-center">
          <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6">
            <Layout className="text-white/10 w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white/60">No deals in this stage</h3>
          <p className="text-sm text-white/40 mt-2">
            Try selecting a different stage or create a new deal.
          </p>
        </div>
      )}
    </div>
  );
}
