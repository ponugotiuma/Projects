'use client';

import React from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Users,
  Target,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  Brain,
  Sparkles,
  Calendar,
  Filter,
  Plus,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';

const data = [
  { name: 'Jan', value: 4000 },
  { name: 'Feb', value: 3000 },
  { name: 'Mar', value: 2000 },
  { name: 'Apr', value: 2780 },
  { name: 'May', value: 1890 },
  { name: 'Jun', value: 2390 },
  { name: 'Jul', value: 3490 },
];

const StatCard = ({ title, value, change, icon: Icon, delay }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
  >
    <Card className="bg-white/5 border-white/5 hover:border-[#D4AF37]/30 transition-all duration-500 overflow-hidden group">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="p-3 rounded-xl bg-white/5 text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-black transition-all duration-500">
            <Icon size={20} />
          </div>
          <div
            className={cn(
              'flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full',
              change.startsWith('+')
                ? 'bg-green-500/10 text-green-400'
                : 'bg-red-500/10 text-red-400'
            )}
          >
            {change}{' '}
            {change.startsWith('+') ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
          </div>
        </div>
        <p className="text-white/40 text-sm font-medium mb-1">{title}</p>
        <h3 className="text-3xl font-bold tracking-tight">{value}</h3>
      </CardContent>
      <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
    </Card>
  </motion.div>
);

const AIInsightCard = () => (
  <Card className="bg-gradient-to-br from-[#D4AF37]/10 to-[#F3E5AB]/5 border-[#D4AF37]/20 relative overflow-hidden group">
    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
      <Brain size={120} className="text-[#D4AF37]" />
    </div>
    <CardHeader>
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-[#D4AF37] flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.4)]">
          <Sparkles className="text-black w-4 h-4 fill-current" />
        </div>
        <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#D4AF37]">
          Centle AI Insight
        </span>
      </div>
      <CardTitle className="text-2xl font-bold">Executive Summary</CardTitle>
      <CardDescription className="text-white/60">
        AI-generated overview for current cycle
      </CardDescription>
    </CardHeader>
    <CardContent className="space-y-4">
      <p className="text-sm leading-relaxed text-white/80">
        Centle Group is seeing a <span className="text-[#D4AF37] font-bold">24% surge</span> in
        high-intent leads for <span className="font-bold">Saasum AI</span>. Referral conversions
        from <span className="font-bold">College Ambassadors</span> are outperforming paid
        acquisition by 3:1.
      </p>
      <div className="flex items-center gap-4 pt-4">
        <Button className="bg-[#D4AF37] hover:bg-[#C5A028] text-black font-bold rounded-xl px-6">
          Optimize Payouts
        </Button>
        <Button variant="ghost" className="text-white/60 hover:text-white hover:bg-white/5">
          View Details
        </Button>
      </div>
    </CardContent>
  </Card>
);

const TaskWidget = () => (
  <Card className="bg-white/5 border-white/5">
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <CardTitle className="text-sm font-medium">Daily Tasks</CardTitle>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-white/40">
        <Plus size={14} />
      </Button>
    </CardHeader>
    <CardContent className="space-y-4">
      {[
        { title: 'Call TechNova CEO', type: 'Call', time: '10:00 AM' },
        { title: 'Approve Referral Payouts', type: 'Finance', time: '1:30 PM' },
        { title: 'Saasum AI Demo', type: 'Meeting', time: '4:00 PM' },
      ].map((task, i) => (
        <div
          key={i}
          className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/5 hover:border-[#D4AF37]/30 transition-all cursor-pointer group"
        >
          <div className="w-2 h-2 rounded-full bg-[#D4AF37]" />
          <div className="flex-1">
            <p className="text-xs font-bold group-hover:text-[#D4AF37] transition-colors">
              {task.title}
            </p>
            <p className="text-[10px] text-white/40">
              {task.type} • {task.time}
            </p>
          </div>
        </div>
      ))}
    </CardContent>
  </Card>
);

const cn = (...inputs: any[]) => inputs.filter(Boolean).join(' ');

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-bold tracking-tight mb-2">
            Executive <span className="text-[#D4AF37]">Dashboard</span>
          </h1>
          <p className="text-white/40">Welcome back, Admin. Here's your ecosystem overview.</p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            className="border-white/5 bg-white/5 hover:bg-white/10 text-white rounded-xl"
          >
            <Calendar className="mr-2 w-4 h-4" /> Last 30 Days
          </Button>
          <Button
            variant="outline"
            className="border-white/5 bg-white/5 hover:bg-white/10 text-white rounded-xl"
          >
            <Filter className="mr-2 w-4 h-4" /> Filter Ventures
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Ecosystem Revenue"
          value="$842,500"
          change="+12.5%"
          icon={TrendingUp}
          delay={0.1}
        />
        <StatCard title="Active Leads" value="1,248" change="+18.2%" icon={Users} delay={0.2} />
        <StatCard title="Won Deals" value="142" change="+5.4%" icon={Target} delay={0.3} />
        <StatCard title="Conversion Rate" value="14.2%" change="-2.1%" icon={Zap} delay={0.4} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Card className="bg-white/5 border-white/5 overflow-hidden">
            <CardHeader>
              <CardTitle>Revenue Trends</CardTitle>
              <CardDescription>Consolidated revenue across all 6 ventures</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px] p-0">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#D4AF37" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    vertical={false}
                    stroke="rgba(255,255,255,0.05)"
                  />
                  <XAxis
                    dataKey="name"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 12 }}
                  />
                  <YAxis
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 12 }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0A0A0A',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '12px',
                    }}
                    itemStyle={{ color: '#D4AF37' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#D4AF37"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorValue)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-white/5 border-white/5">
              <CardHeader>
                <CardTitle>Top Ventures</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { name: 'Saasum AI', share: '34%', color: '#D4AF37' },
                  { name: 'Skill Tank', share: '28%', color: '#D4AF37' },
                  { name: 'Promtal', share: '18%', color: '#D4AF37' },
                  { name: 'Tobofu', share: '12%', color: '#D4AF37' },
                ].map((v, i) => (
                  <div key={i} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-white/60">{v.name}</span>
                      <span className="font-bold">{v.share}</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-[#D4AF37]" style={{ width: v.share }} />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/5">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { user: 'Alex Morgan', action: 'signed up for Saasum AI', time: '2m ago' },
                  { user: 'TechCorp Ltd', action: 'moved to Qualified stage', time: '15m ago' },
                  { user: 'Sarah Chen', action: 'converted via Referral', time: '1h ago' },
                  { user: 'SkillTank', action: 'generated new invoice', time: '3h ago' },
                ].map((a, i) => (
                  <div key={i} className="flex items-start gap-3 text-sm">
                    <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                      <Users size={14} className="text-white/40" />
                    </div>
                    <div>
                      <p>
                        <span className="font-bold text-white/90">{a.user}</span>{' '}
                        <span className="text-white/40">{a.action}</span>
                      </p>
                      <p className="text-[10px] text-[#D4AF37] font-bold">{a.time}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="space-y-8">
          <AIInsightCard />
          <TaskWidget />
          <Card className="bg-[#D4AF37]/5 border-[#D4AF37]/10">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4 border border-white/5">
                <Target className="text-[#D4AF37] w-6 h-6" />
              </div>
              <h4 className="font-bold mb-2">Global Pipeline Health</h4>
              <p className="text-xs text-white/40 mb-6">
                Pipeline is <span className="text-[#D4AF37] font-bold">Strong</span>. Weighted
                forecast for Q3 is $1.2M.
              </p>
              <div className="flex justify-center gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="w-8 h-1.5 rounded-full bg-[#D4AF37]" />
                ))}
                {[6, 7].map((i) => (
                  <div key={i} className="w-8 h-1.5 rounded-full bg-[#D4AF37]/20" />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
