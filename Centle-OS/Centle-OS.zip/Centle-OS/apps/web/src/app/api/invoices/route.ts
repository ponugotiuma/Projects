import sql from '@/app/api/utils/sql';
import { headers } from 'next/headers';
import { auth } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const session = await auth.api.getSession({
      headers: await headers(),
    });

    if (!session) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const invoices = await sql`
      SELECT i.*, d.name as deal_name, v.name as venture_name 
      FROM invoices i
      JOIN deals d ON i.deal_id = d.id
      JOIN ventures v ON d.venture_id = v.id
      ORDER BY i.created_at DESC
    `;

    return Response.json(invoices);
  } catch (error) {
    console.error(error);
    return Response.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth.api.getSession({
      headers: await headers(),
    });

    if (!session) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { deal_id, amount, discount_percent } = body;

    const invoice_number = 'INV-' + Math.random().toString(36).substring(2, 8).toUpperCase();

    const [newInvoice] = await sql`
      INSERT INTO invoices (deal_id, invoice_number, amount, discount_percent, status)
      VALUES (${deal_id}, ${invoice_number}, ${amount}, ${discount_percent}, 'draft')
      RETURNING *
    `;

    return Response.json(newInvoice);
  } catch (error) {
    console.error(error);
    return Response.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
