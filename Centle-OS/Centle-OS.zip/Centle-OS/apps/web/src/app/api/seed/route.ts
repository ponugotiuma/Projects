import sql from '@/app/api/utils/sql';
import argon2 from 'argon2';
import { randomUUID } from 'crypto';

const demoUsers = [
  {
    name: 'Vamshi Krishna',
    email: 'vamshi.admin-centleos@gmail.com',
    password: 'Admin@CentleOS',
    role: 'admin',
    venture_slug: null as string | null,
  },
  {
    name: 'Sai Krishna',
    email: 'saikrishna.manager-centleos@gmail.com',
    password: 'Manager@CentleOS',
    role: 'manager',
    venture_slug: 'saasum-ai',
  },
  {
    name: 'Pavani',
    email: 'pavani.ops-centleos@gmail.com',
    password: 'Ops@CentleOS',
    role: 'operations',
    venture_slug: null as string | null,
  },
  {
    name: 'Priya',
    email: 'priya.sales-centleos@gmail.com',
    password: 'SalesRep@CentleOS',
    role: 'sales',
    venture_slug: null as string | null,
  },
  {
    name: 'Vyshnavi',
    email: 'vyshnavi.ambassador-centleos@gmail.com',
    password: 'Ambassador@CentleOS',
    role: 'ambassador',
    venture_slug: null as string | null,
  },
];

const demoVentures = [
  {
    name: 'Saasum AI',
    slug: 'saasum-ai',
    description: 'Enterprise AI & Automation',
    accent_color: '#D4AF37',
  },
  {
    name: 'Skill Tank',
    slug: 'skill-tank',
    description: 'Modern Upskilling & Learning',
    accent_color: '#D4AF37',
  },
  {
    name: 'Promtal',
    slug: 'promtal',
    description: 'High-Impact Hiring Solutions',
    accent_color: '#D4AF37',
  },
  {
    name: 'Tobofu',
    slug: 'tobofu',
    description: 'Performance Marketing Engine',
    accent_color: '#D4AF37',
  },
  {
    name: 'Maceco',
    slug: 'maceco',
    description: 'Deep Tech Research & Development',
    accent_color: '#D4AF37',
  },
  {
    name: 'Vriddhi',
    slug: 'vriddhi',
    description: 'Strategic Finance & Investment',
    accent_color: '#D4AF37',
  },
];

export async function POST() {
  try {
    const results: string[] = [];

    // 1. Seed ventures
    for (const venture of demoVentures) {
      const existing = await sql`SELECT id FROM ventures WHERE slug = ${venture.slug}`;
      if (existing.length === 0) {
        await sql`
          INSERT INTO ventures (name, slug, description, accent_color)
          VALUES (${venture.name}, ${venture.slug}, ${venture.description}, ${venture.accent_color})
        `;
        results.push(`Created venture: ${venture.name}`);
      }
    }

    // 2. Seed demo users in both auth and legacy tables
    for (const demoUser of demoUsers) {
      const existing = await sql`SELECT id FROM "user" WHERE email = ${demoUser.email}`;

      if (existing.length === 0) {
        const authUserId = randomUUID();
        const now = new Date();
        const hashedPassword = await argon2.hash(demoUser.password);
        const accountId = randomUUID();

        // Auth user table
        await sql`
          INSERT INTO "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
          VALUES (${authUserId}, ${demoUser.name}, ${demoUser.email}, true, ${now}, ${now})
        `;

        // Auth account table (credential provider)
        await sql`
          INSERT INTO account (id, "userId", "accountId", "providerId", password, "createdAt", "updatedAt")
          VALUES (${accountId}, ${authUserId}, ${authUserId}, 'credential', ${hashedPassword}, ${now}, ${now})
        `;

        // Legacy users table
        const legacyUserId = randomUUID();
        const legacyHash = await argon2.hash(demoUser.password);
        await sql`
          INSERT INTO users (id, email, password_hash)
          VALUES (${legacyUserId}, ${demoUser.email}, ${legacyHash})
          ON CONFLICT (email) DO NOTHING
        `;

        const legacyUser = await sql`SELECT id FROM users WHERE email = ${demoUser.email}`;

        if (legacyUser.length > 0) {
          let ventureId: string | null = null;
          if (demoUser.venture_slug) {
            const v = await sql`SELECT id FROM ventures WHERE slug = ${demoUser.venture_slug}`;
            if (v.length > 0) ventureId = v[0].id as string;
          }

          await sql`
            INSERT INTO users_profile (id, full_name, role, venture_id)
            VALUES (${legacyUser[0].id}, ${demoUser.name}, ${demoUser.role}, ${ventureId})
            ON CONFLICT (id) DO UPDATE SET role = ${demoUser.role}, full_name = ${demoUser.name}
          `;
        }

        results.push(`Created user: ${demoUser.name} (${demoUser.role})`);
      } else {
        results.push(`Already exists: ${demoUser.email}`);
      }
    }

    // 3. VYSHNAVI2026 referral code
    const vyshnaviUser =
      await sql`SELECT id FROM users WHERE email = 'vyshnavi.ambassador-centleos@gmail.com'`;
    if (vyshnaviUser.length > 0) {
      const existingCode = await sql`SELECT id FROM referral_codes WHERE code = 'VYSHNAVI2026'`;
      if (existingCode.length === 0) {
        await sql`INSERT INTO referral_codes (user_id, code) VALUES (${vyshnaviUser[0].id}, 'VYSHNAVI2026')`;
        results.push('Created referral code: VYSHNAVI2026');
      } else {
        results.push('Referral code VYSHNAVI2026 already exists');
      }
    }

    // 4. Demo leads
    const existingLeads = await sql`SELECT COUNT(*) as count FROM leads`;
    if (Number(existingLeads[0].count) < 5) {
      const ventures_data = await sql`SELECT id, slug FROM ventures`;
      const ventureMap: Record<string, string> = {};
      for (const v of ventures_data) {
        ventureMap[v.slug as string] = v.id as string;
      }

      const demoLeads = [
        {
          contact_name: 'Arjun Sharma',
          contact_email: 'arjun@techcorp.io',
          company_name: 'TechCorp India',
          source: 'Website',
          status: 'qualified',
          lead_score: 87,
          venture_slug: 'saasum-ai',
          ai_explanation:
            'High engagement: visited pricing page 4x, opened 3 emails, company revenue >$5M',
          next_best_action: 'Send personalized AI demo link. Schedule 30-min discovery call.',
          cross_rec: 'Tobofu — growth marketing to amplify their launch',
        },
        {
          contact_name: 'Divya Reddy',
          contact_email: 'divya@eduplus.com',
          company_name: 'EduPlus',
          source: 'Referral',
          status: 'contacted',
          lead_score: 73,
          venture_slug: 'skill-tank',
          ai_explanation:
            'Education sector match. Referral source increases conversion probability by 40%.',
          next_best_action: 'Follow up within 48h with Skill Tank case study from similar client.',
          cross_rec: 'Saasum AI — automate their student assessment pipeline',
        },
        {
          contact_name: 'Rahul Gupta',
          contact_email: 'rahul@startupnest.co',
          company_name: 'StartupNest',
          source: 'LinkedIn',
          status: 'proposal',
          lead_score: 91,
          venture_slug: 'promtal',
          ai_explanation:
            'Series A startup actively hiring. Decision maker engaged directly on LinkedIn.',
          next_best_action:
            'Deliver custom proposal with ROI calculator. Request final meeting with CTO.',
          cross_rec: 'Tobofu — brand marketing for their product launch',
        },
        {
          contact_name: 'Sneha Patel',
          contact_email: 'sneha@growthco.in',
          company_name: 'GrowthCo',
          source: 'Event',
          status: 'new',
          lead_score: 65,
          venture_slug: 'saasum-ai',
          ai_explanation:
            'Met at AI Summit. Strong interest expressed. Needs nurturing before qualifying.',
          next_best_action:
            'Add to email nurture sequence. Share thought leadership content for 2 weeks.',
          cross_rec: 'Maceco — research partnership could be valuable',
        },
        {
          contact_name: 'Vikram Nair',
          contact_email: 'vikram@finbridge.com',
          company_name: 'FinBridge',
          source: 'College Ambassador',
          status: 'negotiation',
          lead_score: 95,
          venture_slug: 'vriddhi',
          ai_explanation:
            'BFSI sector, $50M AUM. Negotiating enterprise pricing. Very high close probability.',
          next_best_action:
            'Offer custom SLA with 90-day pilot. Escalate to exec sponsor for final push.',
          cross_rec: 'Saasum AI — AI-powered financial analytics integration',
        },
      ];

      for (const lead of demoLeads) {
        await sql`
          INSERT INTO leads (venture_id, status, source, lead_score, contact_name, contact_email, company_name, ai_explanation, next_best_action, cross_venture_recommendation)
          VALUES (
            ${ventureMap[lead.venture_slug] ?? null},
            ${lead.status},
            ${lead.source},
            ${lead.lead_score},
            ${lead.contact_name},
            ${lead.contact_email},
            ${lead.company_name},
            ${lead.ai_explanation},
            ${lead.next_best_action},
            ${lead.cross_rec}
          )
        `;
      }
      results.push('Seeded 5 demo leads');
    }

    // 5. Demo deals
    const existingDeals = await sql`SELECT COUNT(*) as count FROM deals`;
    if (Number(existingDeals[0].count) < 3) {
      const leads_data = await sql`SELECT id FROM leads LIMIT 3`;
      const saasum = await sql`SELECT id FROM ventures WHERE slug = 'saasum-ai'`;
      const saasumId = saasum[0]?.id ?? null;

      const dealData = [
        {
          name: 'Saasum AI Enterprise License',
          value: 250000,
          probability: 75,
          status: 'open',
          idx: 0,
        },
        {
          name: 'Skill Tank Learning Suite Q3',
          value: 85000,
          probability: 60,
          status: 'open',
          idx: 1,
        },
        {
          name: 'Promtal Hiring Platform — Annual',
          value: 120000,
          probability: 90,
          status: 'won',
          idx: 2,
        },
      ];

      for (const deal of dealData) {
        if (!leads_data[deal.idx]) continue;
        const closeDate = new Date();
        closeDate.setDate(closeDate.getDate() + 30 + deal.idx * 15);
        await sql`
          INSERT INTO deals (lead_id, venture_id, name, value, probability, close_date, status)
          VALUES (${leads_data[deal.idx].id}, ${saasumId}, ${deal.name}, ${deal.value}, ${deal.probability}, ${closeDate}, ${deal.status})
        `;
      }
      results.push('Seeded 3 demo deals');
    }

    // 6. Demo invoice for won deal
    const wonDeal = await sql`SELECT id FROM deals WHERE status = 'won' LIMIT 1`;
    if (wonDeal.length > 0) {
      const existingInvoice = await sql`SELECT id FROM invoices WHERE deal_id = ${wonDeal[0].id}`;
      if (existingInvoice.length === 0) {
        await sql`
          INSERT INTO invoices (deal_id, invoice_number, amount, discount_percent, status)
          VALUES (${wonDeal[0].id}, 'INV-2026-001', 120000, 15, 'paid')
        `;
        results.push('Seeded demo invoice INV-2026-001');
      }
    }

    return Response.json({ success: true, results });
  } catch (error) {
    console.error('Seed error:', error);
    return Response.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function GET() {
  try {
    const users = await sql`SELECT COUNT(*) as count FROM "user"`;
    const ventures = await sql`SELECT COUNT(*) as count FROM ventures`;
    const leads = await sql`SELECT COUNT(*) as count FROM leads`;
    const codes = await sql`SELECT COUNT(*) as count FROM referral_codes`;
    return Response.json({
      users: Number(users[0].count),
      ventures: Number(ventures[0].count),
      leads: Number(leads[0].count),
      referralCodes: Number(codes[0].count),
    });
  } catch (error) {
    return Response.json({ error: String(error) }, { status: 500 });
  }
}
