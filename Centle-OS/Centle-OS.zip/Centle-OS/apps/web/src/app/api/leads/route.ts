import sql from '@/app/api/utils/sql';
import { headers } from 'next/headers';
import { auth } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const session = await auth.api.getSession({
      headers: await headers(),
    });

    if (!session) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const leads = await sql`
      SELECT l.*, v.name as venture_name 
      FROM leads l
      LEFT JOIN ventures v ON l.venture_id = v.id
      ORDER BY l.created_at DESC
    `;

    return Response.json(leads);
  } catch (error) {
    console.error(error);
    return Response.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { contact_name, contact_email, company_name, venture_slug, source, type, lookingFor } =
      body;

    // Resolve venture_id from slug
    const [venture] = await sql`SELECT id FROM ventures WHERE slug = ${venture_slug}`;
    const venture_id = venture?.id || null;

    // AI Lead Scoring (Mock Logic)
    const lead_score = Math.floor(Math.random() * 40) + 60; // 60-100
    const ai_explanation =
      'High intent detected based on venture-specific routing. Profile matches high-value client persona.';
    const next_best_action = 'Schedule demo with Lead Rep for ' + (venture_slug || 'Centle Group');
    const cross_venture_recommendation = venture_slug === 'saasum-ai' ? 'Skill Tank' : 'Saasum AI';

    const [newLead] = await sql`
      INSERT INTO leads (
        contact_name, 
        contact_email, 
        company_name, 
        venture_id, 
        source, 
        lead_score, 
        ai_explanation, 
        next_best_action, 
        cross_venture_recommendation
      ) VALUES (
        ${contact_name}, 
        ${contact_email}, 
        ${company_name}, 
        ${venture_id}, 
        ${source}, 
        ${lead_score}, 
        ${ai_explanation}, 
        ${next_best_action}, 
        ${cross_venture_recommendation}
      ) RETURNING *
    `;

    // Create Activity
    await sql`
      INSERT INTO activities (lead_id, type, description)
      VALUES (${newLead.id}, 'signup', 'Lead joined through Gateway Wizard')
    `;

    return Response.json(newLead);
  } catch (error) {
    console.error(error);
    return Response.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
