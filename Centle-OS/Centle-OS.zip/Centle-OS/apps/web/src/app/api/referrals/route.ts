import sql from '@/app/api/utils/sql';
import { headers } from 'next/headers';
import { auth } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const session = await auth.api.getSession({
      headers: await headers(),
    });

    if (!session) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId') || session.user.id;

    const [referralCode] = await sql`
      SELECT * FROM referral_codes WHERE user_id = ${userId}
    `;

    const stats = await sql`
      SELECT 
        COUNT(DISTINCT rc.id) as total_clicks,
        COUNT(DISTINCT l.id) as total_leads,
        COUNT(DISTINCT d.id) as total_deals,
        SUM(d.value) as total_revenue
      FROM referral_codes rcode
      LEFT JOIN referral_clicks rc ON rcode.id = rc.code_id
      LEFT JOIN leads l ON l.source = rcode.code
      LEFT JOIN deals d ON l.id = d.lead_id AND d.status = 'won'
      WHERE rcode.user_id = ${userId}
    `;

    return Response.json({ referralCode, stats: stats[0] });
  } catch (error) {
    console.error(error);
    return Response.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth.api.getSession({
      headers: await headers(),
    });

    if (!session) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const code = 'CENTLE' + Math.random().toString(36).substring(2, 7).toUpperCase();

    const [newCode] = await sql`
      INSERT INTO referral_codes (user_id, code)
      VALUES (${session.user.id}, ${code})
      RETURNING *
    `;

    return Response.json(newCode);
  } catch (error) {
    console.error(error);
    return Response.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
